#!/usr/bin/env python3
"""Task-local launcher: unchanged frozen controllers, stop before next case on unexpected failure."""
import hashlib, importlib.util, json, os, subprocess, sys
from pathlib import Path

source=Path(os.environ['BENCH_SOURCE'])
dll=os.environ['BENCH_DLL']
root=Path(os.environ['BENCH_CAPTURE'])
rtt=Path(os.environ['BENCH_RTT_CAPTURE'])
for p in (root,rtt):p.mkdir()
script=source/'scripts/lean-net-bench'
spec=importlib.util.spec_from_file_location('frozen_matrix',script/'matrix.py')
matrix=importlib.util.module_from_spec(spec);spec.loader.exec_module(matrix)
sizes={'1':265232,'16':293448,'64':291464}
(root/'proof-sizes.json').write_text(json.dumps(sizes,sort_keys=True)+'\n')
keys=('DOTNET_PROCESSOR_COUNT','LEAN_NET_LOG','LEAN_NET_PREFIX','LEAN_NET_SUBNET','LEAN_NET_SOURCE_REVISION','LEAN_NET_SOURCE_ARCHIVE_SHA256','LEAN_NET_BINARY_SOURCE_REVISION')
for p in (root,rtt):
 (p/'environment.json').write_text(json.dumps({k:os.environ.get(k) for k in keys},indent=2,sort_keys=True)+'\n')

def launch(command,label,capture):
 results=capture/'results.jsonl'
 with (capture/'commands.jsonl').open('a') as f:f.write(json.dumps({'label':label,'argv':command})+'\n')
 with (capture/'controller.log').open('a') as log:
  result=subprocess.run(command,cwd=source,stdout=log,stderr=subprocess.STDOUT)
 rows=[json.loads(s) for s in results.read_text().splitlines()] if results.exists() else []
 if not rows or rows[-1].get('label')!=label:raise RuntimeError('No completed result row for '+label)
 row=rows[-1]
 bad={k:v for k,v in row.get('events',{}).items() if v and k.rsplit('/',1)[-1] in ('invalid','violation','local_failure')}
 codes=row.get('node_exit_codes',{})
 if row.get('error') or row.get('redials') or row.get('peers_lost_at_end') or bad or not codes or any(x!=0 for x in codes.values()):
  raise RuntimeError('Unexpected error; campaign stopped before next case: '+json.dumps(row))
 if result.returncode and not row.get('missing'):raise RuntimeError('Controller failed unexpectedly for '+label)
 print(json.dumps({k:row.get(k) for k in ('label','completed','missing','error','actual_offered_objects_per_s','goodput_objects_per_s_per_receiver','redials','peers_lost_at_end')}),flush=True)

for rep in (1,2):
 for name,_ in matrix.scenarios(300000,sizes):
  label=name+'-rep'+str(rep)
  command=[sys.executable,str(script/'matrix.py'),'--test-dll',dll,'--out',str(root/'runs'),'--results',str(root/'results.jsonl'),'--repetitions','2','--proof-sizes',str(root/'proof-sizes.json'),'--match',label]
  launch(command,label,root)
for rep in (1,2):
 for binding in ('rlpx','ethp2p'):
  for rate in (8,32):
   label=f'rtt200-{binding}-tx16-r{rate}-rep{rep}'
   command=[sys.executable,str(script/'netbench.py'),'run','--netns','--test-dll',dll,'--topology','pair','--binding',binding,'--kind','1','--transactions-per-object','16','--proof-bytes','293448','--objects',str(6*rate),'--warmup','2','--burst',str(rate),'--interval-ms','1000','--rtt-ms','200','--rate-mbit','100','--loss','0','--timeout','90','--label',label,'--out',str(rtt/'runs'),'--results',str(rtt/'results.jsonl')]
   launch(command,label,rtt)
