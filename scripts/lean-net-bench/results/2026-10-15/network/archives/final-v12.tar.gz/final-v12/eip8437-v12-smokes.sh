#!/usr/bin/env bash
set -euo pipefail
: "${BENCH_SOURCE:?Set the exact coherent v12 source directory}"
: "${BENCH_DLL:?Set the validated v12 test assembly}"
: "${BENCH_REVISION:?Set full frozen source revision}"
: "${BENCH_ARCHIVE_SHA256:?Set verified source archive SHA256}"
: "${BENCH_SMOKES:?Set a NEW smoke capture directory}"
export DOTNET_PROCESSOR_COUNT=2
export LEAN_NET_SOURCE_REVISION="$BENCH_REVISION"
export LEAN_NET_BINARY_SOURCE_REVISION="$BENCH_REVISION"
export LEAN_NET_SOURCE_ARCHIVE_SHA256="$BENCH_ARCHIVE_SHA256"
export LEAN_NET_PREFIX=lnv12s
export LEAN_NET_SUBNET=10.78
mkdir "$BENCH_SMOKES"
cd "$BENCH_SOURCE"
for binding in rlpx ethp2p; do
 for workload in maximum eth16; do
  if [ "$workload" = maximum ]; then bytes=8388608; transactions=1; else bytes=293448; transactions=16; fi
  nice -n 10 python3 scripts/lean-net-bench/netbench.py run --netns \
   --test-dll "$BENCH_DLL" --topology pair --binding "$binding" \
   --kind 1 --transactions-per-object "$transactions" --proof-bytes "$bytes" \
   --objects 2 --warmup 1 --burst 1 --interval-ms 1000 \
   --rtt-ms 50 --rate-mbit 100 --loss 0 --timeout 90 \
   --label "smoke-${workload}-${binding}" --out "$BENCH_SMOKES/runs" \
   --results "$BENCH_SMOKES/results.jsonl" >> "$BENCH_SMOKES/run.log" 2>&1
  python3 - "$BENCH_SMOKES/results.jsonl" <<'PY'
import json, re, sys
from pathlib import Path
with open(sys.argv[1]) as stream:
    row = json.loads([line for line in stream if line.strip()][-1])
if row.get('error') or row.get('missing') != 0 or row.get('completed') != 2:
    raise SystemExit('Smoke failed: ' + json.dumps(row))
if row.get('validated_receiver_deliveries') != row.get('expected_receiver_deliveries'):
    raise SystemExit('Smoke receiver delivery count mismatch')
if not row.get('node_exit_codes') or any(code != 0 for code in row['node_exit_codes'].values()):
    raise SystemExit('Smoke child process exit failure')
bad_events = {key: count for key, count in row.get('events', {}).items()
              if key.rsplit('/', 1)[-1] in ('local_failure', 'invalid', 'violation', 'expired', 'request_expired') and count}
if bad_events or row.get('peers_lost_at_end'):
    raise SystemExit('Smoke local/protocol/peer failure: ' + json.dumps({'events': bad_events, 'peers_lost': row.get('peers_lost_at_end')}))
run_dir = Path(row['run_dir'])
for result_path in sorted(run_dir.glob('result.*.json')):
    result = json.loads(result_path.read_text())
    if result.get('peers_at_end') != 1:
        raise SystemExit('Smoke pair lost peer: ' + str(result_path))
for log_path in sorted(run_dir.glob('node.*.log')):
    log = log_path.read_text()
    if 'no decoder working-space budget' in log or re.search(r'decoderBudgetRefusals[\s:=]+[1-9]', log):
        raise SystemExit('Smoke decoder budget refusal: ' + str(log_path))
print(row['label'], 'PASS', 'completed', row['completed'], 'children', row['node_exit_codes'],
      'latency_ms', row.get('latency_ms'), 'goodput_window_s', row.get('goodput_window_s'),
      'peers_lost', row.get('peers_lost_at_end'), 'redials', row.get('redials'), 'events', row.get('events'))
PY
 done
done
printf 'Smokes completed; full matrix still requires the root agent snapshot/review gate.\n'
