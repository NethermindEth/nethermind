#!/usr/bin/env bash
set -euo pipefail
: "${BENCH_REVISION:?Set exact frozen V12 revision}"
: "${BENCH_ARCHIVE_SHA256:?Set exact V12 source archive SHA256}"
TASK=/root/lean-bench-20261015
ARCHIVE="$TASK/lean-net-source-20261015-v12.tar.gz"
STAGING="$TASK/source-v12-staging"
printf '%s  %s\n' "$BENCH_ARCHIVE_SHA256" "$ARCHIVE" | sha256sum -c -
mkdir "$STAGING"
tar -xzf "$ARCHIVE" -C "$STAGING"
# Review tracked deletions separately before sync; preserve unchanged source mtimes.
rsync -r --checksum "$STAGING/" "$TASK/source/"
printf 'source_revision=%s\narchive_sha256=%s\nstaging=%s\n' "$BENCH_REVISION" "$BENCH_ARCHIVE_SHA256" "$STAGING"
