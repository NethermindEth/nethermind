#!/usr/bin/env bash
set -euo pipefail
: "${BENCH_SOURCE:?Set the exact v7 source directory}"
: "${BENCH_DLL:?Set the exact validated v7 test assembly}"
: "${BENCH_REVISION:?Set the full tracked source revision}"
: "${BENCH_ARCHIVE_SHA256:?Set the actual source archive SHA256}"
: "${BENCH_CAPTURE:?Set a new capture directory}"
export LEAN_NET_SOURCE_REVISION="$BENCH_REVISION"
export LEAN_NET_BINARY_SOURCE_REVISION="$BENCH_REVISION"
export LEAN_NET_SOURCE_ARCHIVE_SHA256="$BENCH_ARCHIVE_SHA256"
export LEAN_NET_PREFIX=lnv7
export LEAN_NET_SUBNET=10.78
mkdir "$BENCH_CAPTURE"
printf '%s\n' '{"1":265232,"16":293448,"64":291464}' > "$BENCH_CAPTURE/proof-sizes.json"
cd "$BENCH_SOURCE"
python3 scripts/lean-net-bench/test_metrics.py > "$BENCH_CAPTURE/reporting-checks.log" 2>&1
python3 -O scripts/lean-net-bench/test_metrics.py >> "$BENCH_CAPTURE/reporting-checks.log" 2>&1
# The root agent must first confirm the separate v7 maximum-object/ETH recovery smokes passed.
python3 scripts/lean-net-bench/matrix.py --plan \
 --test-dll "$BENCH_DLL" --out "$BENCH_CAPTURE/runs" \
 --results "$BENCH_CAPTURE/results.jsonl" --repetitions 2 \
 --proof-sizes "$BENCH_CAPTURE/proof-sizes.json" > "$BENCH_CAPTURE/matrix-plan.log"
python3 scripts/lean-net-bench/matrix.py \
 --test-dll "$BENCH_DLL" --out "$BENCH_CAPTURE/runs" \
 --results "$BENCH_CAPTURE/results.jsonl" --repetitions 2 \
 --proof-sizes "$BENCH_CAPTURE/proof-sizes.json" > "$BENCH_CAPTURE/matrix.log" 2>&1
