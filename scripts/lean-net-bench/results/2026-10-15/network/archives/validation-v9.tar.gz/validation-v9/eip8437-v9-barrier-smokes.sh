#!/usr/bin/env bash
set -euo pipefail
: "${BENCH_SOURCE:?Set the exact frozen v9 source directory}"
: "${BENCH_DLL:?Set the validated v9 test assembly}"
: "${BENCH_REVISION:?Set full source revision}"
: "${BENCH_ARCHIVE_SHA256:?Set verified archive SHA256}"
: "${BENCH_BARRIER_SMOKES:?Set a NEW barrier diagnostic directory}"
export DOTNET_PROCESSOR_COUNT=2
export LEAN_NET_SOURCE_REVISION="$BENCH_REVISION"
export LEAN_NET_BINARY_SOURCE_REVISION="$BENCH_REVISION"
export LEAN_NET_SOURCE_ARCHIVE_SHA256="$BENCH_ARCHIVE_SHA256"
export LEAN_NET_PREFIX=lnv9b
export LEAN_NET_SUBNET=10.79
mkdir "$BENCH_BARRIER_SMOKES"
cd "$BENCH_SOURCE"
for scenario in zero-allorigins chain4 broadcast; do
 args=(--binding ethp2p --kind 1 --topology pair --origins 0 --objects 2 --warmup 1 --burst 1 --interval-ms 1000)
 if [ "$scenario" = zero-allorigins ]; then args=(--binding ethp2p --kind 1 --topology pair --origins all --objects 2 --warmup 0 --burst 1 --interval-ms 1000); fi
 if [ "$scenario" = chain4 ]; then args=(--binding ethp2p --kind 1 --topology chain4 --origins all --objects 4 --warmup 2 --burst 1 --interval-ms 1000); fi
 if [ "$scenario" = broadcast ]; then args=(--binding ethp2p --broadcast --kind 2 --topology pair --origins 0 --objects 1 --warmup 1 --burst 1 --interval-ms 12000); fi
 nice -n 10 python3 scripts/lean-net-bench/netbench.py run --netns \
  --test-dll "$BENCH_DLL" "${args[@]}" --proof-bytes 293448 \
  --rtt-ms 50 --rate-mbit 100 --loss 0 --timeout 90 \
  --label "barrier-${scenario}" --out "$BENCH_BARRIER_SMOKES/runs" \
  --results "$BENCH_BARRIER_SMOKES/results.jsonl" >> "$BENCH_BARRIER_SMOKES/run.log" 2>&1
 python3 - "$BENCH_BARRIER_SMOKES/results.jsonl" <<'PY'
import json, sys
from pathlib import Path
row=json.loads(Path(sys.argv[1]).read_text().splitlines()[-1])
barrier=row.get('warmup_barrier', {})
if row.get('error') or row.get('missing') != 0 or any(code != 0 for code in row.get('node_exit_codes', {}).values()):
 raise SystemExit('Barrier diagnostic failed: ' + json.dumps(row))
if barrier.get('completed_nodes') != row['nodes'] or barrier.get('error'):
 raise SystemExit('Warmup barrier did not cover all nodes')
start=barrier['measured_start_unix_ns']
if start - barrier['observed_unix_ns'] < 4_000_000_000:
 raise SystemExit('Insufficient common-start scheduling margin')
shards=[]
measured_shards=[]
for p in sorted(Path(row['run_dir']).glob('result.*.json')):
 node=json.loads(p.read_text())
 if node['warmup_completed_at_idle'] != row['warmup'] or node['warmup_completed_at_start'] != row['warmup']:
  raise SystemExit('Warmup overlaps CPU/measurement baseline')
 if node['warmup_completed_ns'] > node['idle_snapshot_ns']:
  raise SystemExit('Warmup completion occurred after idle sampling')
 for index,when in node['originated'].items():
  if int(index) >= row['warmup'] and when < node['snapshot_before_ns']:
   raise SystemExit('Measured origination precedes start snapshot')
 shards.append(node.get('shards_accepted',0))
 measured_shards.append(node.get('shards_accepted_measured',0))
if row.get('broadcast'):
 if not any(measured_shards) or row.get('broadcast_shards_accepted_measured',0) <= 0:
  raise SystemExit('Broadcast diagnostic accepted no MEASURED shards')
 for log_path in Path(row['run_dir']).glob('node.*.log'):
  if 'broadcast was not originated' in log_path.read_text():
   raise SystemExit('Broadcast origination refused: ' + str(log_path))
print(row['label'],'PASS','barrier',barrier,'cpu_quality',row.get('cpu_snapshot_quality'),'lifetime_shards',shards,'measured_shards',measured_shards)
PY
done
