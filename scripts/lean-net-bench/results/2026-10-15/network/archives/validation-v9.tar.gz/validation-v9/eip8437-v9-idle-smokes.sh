#!/usr/bin/env bash
set -euo pipefail
: "${BENCH_SOURCE:?Set exact frozen V9 source directory}"
: "${BENCH_DLL:?Set validated V9 assembly}"
: "${BENCH_REVISION:?Set full frozen source revision}"
: "${BENCH_ARCHIVE_SHA256:?Set verified archive SHA256}"
: "${BENCH_IDLE_SMOKES:?Set a NEW idle diagnostic directory}"
export DOTNET_PROCESSOR_COUNT=2
export LEAN_NET_SOURCE_REVISION="$BENCH_REVISION"
export LEAN_NET_BINARY_SOURCE_REVISION="$BENCH_REVISION"
export LEAN_NET_SOURCE_ARCHIVE_SHA256="$BENCH_ARCHIVE_SHA256"
export LEAN_NET_PREFIX=lnv9i
export LEAN_NET_SUBNET=10.79
mkdir "$BENCH_IDLE_SMOKES"
cd "$BENCH_SOURCE"
for binding in rlpx ethp2p; do
 nice -n 10 python3 scripts/lean-net-bench/netbench.py run --netns \
  --test-dll "$BENCH_DLL" --topology pair --binding "$binding" \
  --kind 1 --transactions-per-object 16 --proof-bytes 293448 \
  --objects 1 --warmup 2 --burst 1 --interval-ms 35000 \
  --rtt-ms 50 --rate-mbit 100 --loss 0 --timeout 120 \
  --label "idle35-${binding}" --out "$BENCH_IDLE_SMOKES/runs" \
  --results "$BENCH_IDLE_SMOKES/results.jsonl" >> "$BENCH_IDLE_SMOKES/run.log" 2>&1
 python3 - "$BENCH_IDLE_SMOKES/results.jsonl" <<'PY'
import json,sys
from pathlib import Path
row=json.loads(Path(sys.argv[1]).read_text().splitlines()[-1])
if row.get('error') or row.get('missing') != 0 or row.get('completed') != 1:
 raise SystemExit('Idle diagnostic incomplete: '+json.dumps(row))
if row.get('redials') or row.get('peers_lost_at_end') or any(code != 0 for code in row.get('node_exit_codes',{}).values()):
 raise SystemExit('Idle diagnostic peer/session failure: '+json.dumps(row))
run=Path(row['run_dir'])
origin=json.loads((run/'result.0.json').read_text())
gap=(origin['originated']['1']-origin['originated']['0'])/1e9
if gap<34.9: raise SystemExit('Warmups did not span the required idle interval')
for p in run.glob('result.*.json'):
 result=json.loads(p.read_text())
 if result['peers_at_end']!=1 or result['warmup_completed_at_idle']!=2 or result['warmup_completed_at_start']!=2:
  raise SystemExit('Idle diagnostic did not retain both warmups and its peer: '+str(p))
for key,count in row.get('events',{}).items():
 if count and key.rsplit('/',1)[-1] in ('local_failure','invalid','violation'):
  raise SystemExit('Idle diagnostic event: '+key)
print(row['label'],'PASS','warmup_gap_s',gap,'redials',row['redials'],'peer_loss',row['peers_lost_at_end'],'child_exits',row['node_exit_codes'])
PY
done
