#!/usr/bin/env bash
set -euo pipefail
: "${BENCH_SOURCE:?Set the extracted coherent v9 source directory}"
: "${BENCH_DLL:?Set the resulting v9 Network.Test DLL path}"
: "${BENCH_REVISION:?Set the full frozen v9 revision}"
: "${BENCH_ARCHIVE_SHA256:?Set the verified archive SHA256}"
: "${BENCH_VALIDATION:?Set a NEW validation directory}"
export DOTNET_PROCESSOR_COUNT=2
export LEAN_NET_SOURCE_REVISION="$BENCH_REVISION"
export LEAN_NET_BINARY_SOURCE_REVISION="$BENCH_REVISION"
export LEAN_NET_SOURCE_ARCHIVE_SHA256="$BENCH_ARCHIVE_SHA256"
export LEAN_NET_PREFIX=lnv9s
export LEAN_NET_SUBNET=10.78
mkdir "$BENCH_VALIDATION"
cd "$BENCH_SOURCE"
printf 'source_revision=%s\nsource_archive_sha256=%s\n' "$BENCH_REVISION" "$BENCH_ARCHIVE_SHA256" > "$BENCH_VALIDATION/source.txt"
nice -n 10 dotnet build src/Nethermind/Nethermind.Network.Test/Nethermind.Network.Test.csproj \
 -c Release --disable-build-servers -m:1 \
 -p:CheckForOverflowUnderflow=false -p:NuGetAudit=true > "$BENCH_VALIDATION/build.log" 2>&1
find "$(dirname "$BENCH_DLL")" -maxdepth 1 -type f -name '*.dll' -print0 | sort -z | xargs -0 sha256sum > "$BENCH_VALIDATION/runtime-dlls.sha256"
sha256sum "$BENCH_DLL" > "$BENCH_VALIDATION/binary.sha256"
dotnet --info > "$BENCH_VALIDATION/dotnet.txt"
nice -n 10 dotnet "$BENCH_DLL" --filter 'FullyQualifiedName~LeanNetBenchFixtureTests' \
 --minimum-expected-tests 1 > "$BENCH_VALIDATION/fixture.log" 2>&1
nice -n 10 dotnet "$BENCH_DLL" --filter 'FullyQualifiedName~LeanEthp2pQuicTests' \
 --minimum-expected-tests 16 > "$BENCH_VALIDATION/quic.log" 2>&1
nice -n 10 dotnet "$BENCH_DLL" \
 --filter 'FullyQualifiedName~LeanEthp2pTests|FullyQualifiedName~LeanObjectTransportTests|FullyQualifiedName~LeanObjectTransportLifecycleTests|FullyQualifiedName~Lean1ProtocolHandlerTests|FullyQualifiedName~LeanTransportTests|FullyQualifiedName~LeanBroadcastTests|FullyQualifiedName~Lean_ETH_|FullyQualifiedName~SessionMonitorTests' \
 --minimum-expected-tests 1 > "$BENCH_VALIDATION/transport.log" 2>&1
python3 scripts/lean-net-bench/test_metrics.py > "$BENCH_VALIDATION/python.log" 2>&1
python3 -O scripts/lean-net-bench/test_metrics.py >> "$BENCH_VALIDATION/python.log" 2>&1
printf 'Scoped build/fixture/Python checks returned zero. Inspect current Linux test counts and require zero QUIC skips. Run all diagnostics and saturation checks before matrix gate.\n'
