# Source the existing isolated task toolchain environment before this file.
: "${BENCH_REVISION:?Set the full coherent v9 source commit}"
: "${BENCH_ARCHIVE_SHA256:?Set the verified v9 archive SHA256}"
export DOTNET_PROCESSOR_COUNT=2
export LEAN_NET_PREFIX=lnv9
export LEAN_NET_SUBNET=10.78
export LEAN_NET_SOURCE_REVISION="$BENCH_REVISION"
export LEAN_NET_SOURCE_ARCHIVE_SHA256="$BENCH_ARCHIVE_SHA256"
export LEAN_NET_BINARY_SOURCE_REVISION="$BENCH_REVISION"
export LEAN_NET_LOG='filter:violation|invalid|refused|failure|failed|disconnect|timeout'
