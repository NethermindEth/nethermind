#!/usr/bin/env bash
set -euo pipefail
: "${BENCH_SOURCE:?Set immutable V9 staging source}"
: "${BENCH_DLL:?Set preserved V9 assembly path}"
: "${BENCH_BASELINE:?Set a NEW saturation-check directory}"
: "${BENCH_REVISION:?Set the exact V9 revision}"
: "${BENCH_ARCHIVE_SHA256:?Set the verified V9 archive SHA256}"
export DOTNET_PROCESSOR_COUNT=2
export LEAN_NET_SOURCE_REVISION="$BENCH_REVISION"
export LEAN_NET_BINARY_SOURCE_REVISION="$LEAN_NET_SOURCE_REVISION"
export LEAN_NET_SOURCE_ARCHIVE_SHA256="$BENCH_ARCHIVE_SHA256"
export LEAN_NET_PREFIX=lnv9base
export LEAN_NET_SUBNET=10.79
export LEAN_NET_LOG='filter:violation|invalid|refused|failure|failed|disconnect|timeout'
mkdir "$BENCH_BASELINE"
cd "$BENCH_SOURCE"
python3 - "$BENCH_BASELINE/environment.json" <<'PY'
import json,os,sys
keys=('DOTNET_PROCESSOR_COUNT','LEAN_NET_LOG','LEAN_NET_PREFIX','LEAN_NET_SUBNET','LEAN_NET_SOURCE_REVISION','LEAN_NET_SOURCE_ARCHIVE_SHA256','LEAN_NET_BINARY_SOURCE_REVISION')
open(sys.argv[1],'w').write(json.dumps({k:os.environ[k] for k in keys},indent=2)+'\n')
PY
for binding in rlpx ethp2p; do
 for count in 16; do
  if [ "$count" = 1 ]; then bytes=265232; else bytes=293448; fi
  nice -n 10 python3 scripts/lean-net-bench/netbench.py run --netns \
   --test-dll "$BENCH_DLL" --topology pair --binding "$binding" --kind 1 \
   --transactions-per-object "$count" --proof-bytes "$bytes" \
   --objects 192 --warmup 2 --burst 32 --interval-ms 1000 \
   --rtt-ms 50 --rate-mbit 100 --loss 0 --timeout 90 \
   --label "pipeline-diagnostic-v9-${binding}-tx${count}-r32" --out "$BENCH_BASELINE/runs" \
   --results "$BENCH_BASELINE/results.jsonl" >> "$BENCH_BASELINE/run.log" 2>&1
  python3 - "$BENCH_BASELINE/results.jsonl" <<'PY'
import json,sys
from pathlib import Path
r=json.loads(Path(sys.argv[1]).read_text().splitlines()[-1])
bad={k:v for k,v in r.get('events',{}).items() if v and k.rsplit('/',1)[-1] in ('local_failure','invalid','violation')}
if r.get('error') or r.get('redials') or r.get('peers_lost_at_end') or bad or any(code!=0 for code in r.get('node_exit_codes',{}).values()):
 raise SystemExit('Unexpected baseline failure: '+json.dumps(r))
print(r['label'],'completed',r.get('completed'),'missing',r.get('missing'),'actual_objects_s',r.get('actual_offered_objects_per_s'),
      'goodput_objects_s',r.get('goodput_objects_per_s_per_receiver'),'peers_lost',r.get('peers_lost_at_end'),'redials',r.get('redials'))
PY
 done
done
